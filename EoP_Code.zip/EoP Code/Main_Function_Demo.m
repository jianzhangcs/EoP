

ImageIN = 'lena.tif';

Dic = Fast_Dic_Training_and_Testing(ImageIN);

Fast_Estimation_by_Dic(ImageIN,Dic);


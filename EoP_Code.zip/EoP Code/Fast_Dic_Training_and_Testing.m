function [Dic]=Fast_Dic_Training_and_Testing(ImageIN)
%Jian Zhang 2010.11.22


block_size=8;
L = 3;
m = 256;
Img = imread(ImageIN);
if size(Img,3) == 3
    Yl = double(rgb2gray(Img));
else
    Yl = double(Img);
end

[blocks,idx] = my_im2col(Yl,[block_size,block_size],4);

param.errorFlag=0;
param.K=m;
param.numIteration=40;
param.InitializationMethod='DataElements';
param.TrueDictionary=0;
param.Method='KSVD';
param.L=L;
[Dic,output] = TrainDic_Fast(blocks,param);
savefile = [ImageIN '_BlockSize_8x8_DicNum_256.mat'];
save(savefile,'Dic');


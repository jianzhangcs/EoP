function []=Fast_Estimation_by_Dic(ImageIN,Dic)

Img = imread(ImageIN);
if size(Img,3) == 3
    Yh = double(rgb2gray(Img));
else
    Yh = double(Img);
end

sigma = 0;
Yh = Yh + sigma*randn(size(Yh));

[NN1,NN2] = size(Yh);
block_size = 8;
bb = 8;

[blocks,idx] = my_im2col(Yh,[block_size,block_size],8);

Tol = 500;
for L= 1:14
    for jj = 1:30000:size(blocks,2)
        jumpSize = min(jj+30000-1,size(blocks,2));
        %Coefs = mexOMPerrIterative(blocks(:,jj:jumpSize),Dictionary,errT);
        Coefs = omp(Dic'*blocks(:,jj:jumpSize),Dic'*Dic,L);
        %Coefs = OMP2(Dic,blocks(:,jj:jumpSize),Dic'*Dic,Tol/L);
        Recon_blocks(:,jj:jumpSize)= Dic*Coefs ;
        
        Non_Zero_Coefs = (Coefs~=0);
        Num_Atoms = sum(Non_Zero_Coefs,2);
        Num_Atoms = full(Num_Atoms);
        %        figure;plot(Num_Atoms);      
        %Num_Atoms(Num_Atoms==0)=1;
        NonZeroInd = find(Num_Atoms>0);
        NonZero_Atom = Num_Atoms(NonZeroInd);
        NonZero_Atom_rate = NonZero_Atom./sum(NonZero_Atom);
        Atoms_Pi = NonZero_Atom_rate./sum(NonZero_Atom_rate);
        
%         AbsCoefs = abs(Coefs);
%         Energy_Coefs = sum(AbsCoefs,2);
%         Energy_Coefs = full(Energy_Coefs);
%         Energy_Coefs = Energy_Coefs./sum(Energy_Coefs);
%         
%         Atom_rate = Atoms_Pi.*Energy_Coefs;
%             
%         NonZeroInd = find(Atom_rate>0);
%         NonZero_Atom_rate = Atom_rate(NonZeroInd);
%         NonZero_Atom_rate = NonZero_Atom_rate./sum(NonZero_Atom_rate);

        %Atom_rate_vec = zeros(size(Energy_Coefs));
        %Atom_rate_vec(NonZeroInd) = NonZero_Atom_rate;
        
        
        Entro(L) = -sum(Atoms_Pi.*log2(Atoms_Pi));
        %Entro(L) = -sum(NonZero_Atom_rate.*log2(NonZero_Atom_rate));
        
        
    end
    
    count = 1;
    Weight = zeros(NN1,NN2);
    IMout = zeros(NN1,NN2);
    [rows,cols] = ind2sub(size(Yh)-bb+1,idx);
    for i  = 1:length(cols)
        col = cols(i); row = rows(i);
        block =reshape(Recon_blocks(:,count),[bb,bb]);
        IMout(row:row+bb-1,col:col+bb-1)=IMout(row:row+bb-1,col:col+bb-1)+block;
        Weight(row:row+bb-1,col:col+bb-1)=Weight(row:row+bb-1,col:col+bb-1)+ones(bb);
        count = count+1;
    end;
    
    YY = IMout./Weight;
    PSNR_Value(L) = csnr(YY,Yh,10,10);
    SSIM_Value(L)= cal_ssim(YY,Yh,10,10);
    %fprintf(fp,'%f\n',cal_ssim(YY,Yh,10,10));
    %fprintf(fp_psnr,'%f\n',csnr(YY,Yh,10,10));
    %    figure;imshow(uint8(YY));
    %title(['lena' ' Number Of Coeffients is ',num2str(L)]);
    ImageName = ['NumOfCoefs_',num2str(L),'.bmp'];
    imwrite(uint8(YY),ImageName,'bmp');
end
%fclose(fp);
%fclose(fp_psnr);
%figure;plot(PSNR_Value);title('PSNR');
%figure;plot(SSIM_Value);title('SSIM');
figure;plot(Entro);title('EoP');
%pause

end

